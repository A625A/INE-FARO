# INE FARO

Prototipo del Datatón INE Guatemala 2026 para investigar contrastes territoriales
entre ocupación en el sector informal, condiciones de vida y producción.

M-05 integra Empleo e ingresos (ENEIC IV-2025), Territorio y hogares
(ENCOVI y Banguat 2023), Producción (VAB informal nacional), Radar de inteligencia
y Metodología y calidad. La demostración funciona con los agregados y recursos
locales. Abre por defecto en Empleo e ingresos.

## Ejecutar la demostración

Desde la raíz, con Python 3.12 o posterior. Se verificó con Python 3.14.

```sh
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

En Windows, extraer el ZIP y abrir PowerShell en la carpeta que contiene
`app.py`. Con Python 3.14 instalado:

```powershell
py -3.14 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m streamlit run app.py
```

Abrir [Streamlit local](http://localhost:8501). Una vez instaladas las
dependencias, la demo funciona sin conexión.

Para generar la demo desde el repositorio, usar el mismo entorno y un nombre
de ZIP nuevo. En PowerShell:

```powershell
.\.venv\Scripts\python.exe -m scripts.empacar_m05 --output faro-m05.zip
Expand-Archive -LiteralPath faro-m05.zip -DestinationPath faro-demo
```

En macOS o Linux, usar `python -m scripts.empacar_m05 --output faro-m05.zip`.
Consulta la [documentación de M-05](docs/M05_IMPLEMENTACION.md) y el
[informe de evaluación](docs/evaluation/m05_final/INFORME.md).

El paquete del jurado incluye la [presentación](presentacion.pdf), el
[guion](docs/guion_demo.md) y capturas para mostrar el contraste de
Chimaltenango y Alta Verapaz. La [revisión final](docs/revision_final.md)
describe los controles y el [checklist](docs/checklist_entrega.md) registra
los pasos de ensayo y entrega.

## Reproducir el corte completo

El ZIP de demo trae los datos agregados. Para recalcular los datos o repetir
la suite completa, trabajar en un checkout del repositorio. Usar los SAV de
ENCOVI y los XLSX departamentales y DINESE del corte. Las rutas e inventario
figuran en [fuentes.csv](docs/fuentes.csv).

1. Usar el [contrato ENEIC](docs/ENEIC_CONTRATO_M05.md) para preparar los
   archivos de IV-2025. `python scripts/procesar_eneic.py --download` recupera
   y valida los archivos autorizados y regenera sus agregados.
2. Colocar los XLSX nacionales de VAB en `data/raw/banguat_nacional/`,
   manteniendo los nombres y las huellas del
   [contrato VAB](docs/VAB_CONTRATO_M05.md). Verificar también el cuadro
   departamental de Banguat del mismo contrato.
3. Desde el repositorio, ejecutar en ese orden:

   ```sh
   python scripts/calcular_indicadores_encovi.py
   python scripts/procesar_hogares.py
   python scripts/procesar_pib.py
   python scripts/procesar_vab_informal.py
   python scripts/build_matriz.py
   python scripts/radar.py --mode standard --output-dir data/processed
   python docs/evaluation/m05_final/validar_consumo.py
   python -m pytest -q
   ```

## Reproducir I-04 e I-05

Desde la raíz, con el entorno anterior o con Python 3.12 o posterior:

```sh
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python scripts/procesar_pib.py
python scripts/auditar_dinese.py
python -m pytest -q
```

Las ejecuciones sin `--download` funcionan sin red con los XLSX originales de
`data/raw/banguat/` y `data/raw/dinese/`. No requieren credenciales ni nube.
Si faltan, añadir `--download` a cada comando: usa las URL oficiales fijadas en
`data/reference/fuentes_I04_I05.json` y verifica SHA-256. No sobrescribe archivos
existentes distintos ni acepta automáticamente una revisión oficial nueva.
Los binarios ya rastreados se conservan; nuevas descargas quedan ignoradas.

Los comandos admiten `--input-dir`, `--output-dir` y `--evidence-dir`.
El SHA-256 se exige también sin descarga. Una versión nueva requiere revisar
fuentes y controles y actualizar el manifiesto. `--manifest` permite seleccionar
un manifiesto alternativo ya revisado; no valida por sí mismo su origen oficial.
PIB admite `--year` entre 2013 y 2024, por defecto 2023. Al probar otro año usar
otro directorio para conservar los CSV 2023 destinados a ENCOVI.
Cada tarea valida sus insumos completos antes de escribir. Si una ejecución
falla, no usar las salidas de una ejecución previa como si fueran nuevas.

## Resultados y contratos

- `data/processed/pib_departamental.csv`: 22 departamentos, PIB total, 17 grupos
  de valor agregado e impuestos; corrientes y volumen encadenado separados.
- `data/processed/pib_per_capita.csv`: producción por habitante en quetzales.
- `data/processed/pib_conciliacion.csv`: nacional y Extrarregional, fuera del mapa.
- `data/processed/dinese_resumen.csv`: conteos por año/departamento/sección/movimiento.
  Sólo uso descriptivo transversal; crecimiento excluido del radar.
- `docs/evidencia/`: hashes, controles, procedencia y revisión de fuentes oficiales.

Consultar [metadatos PIB](docs/metadata_pib.md), [dictamen DINESE](docs/viabilidad_dinese.md),
[contratos](docs/CONTRATOS_DE_DATOS.md), [especificación](docs/specs/I-04-I-05.md),
[estado](docs/ESTADO_PROYECTO.md) y [preparación Git](docs/git_integracion.md).

Los tests ejercitan los comandos completos con controles oficiales y copias
deliberadamente inválidas. No hay un verificador de tipos configurado; se comprueba
la sintaxis con `python -m compileall -q scripts tests` además de las pruebas.

## Cautelas científicas

PIB no es ingreso ni consumo de hogares. No sumar medidas distintas ni exigir
aditividad a volúmenes encadenados. Las empresas DINESE no son personas ocupadas;
un aumento de registros no prueba creación empresarial ni formalización laboral.

La medición territorial usa la proporción de población ocupada en el sector
informal según ENCOVI 2023. M-01 reproduce 70.3 % a escala nacional y documenta
el universo, los ponderadores y la precisión aproximada. La vista de empleo usa
los agregados públicos de ENEIC IV-2025.

Fuentes: [Banguat](https://banguat.gob.gt/page/cuadros-estadisticos-por-departamento-2013-2024),
[DINESE](https://datos.ine.gob.gt/dataset/directorio-nacional-estadistico-de-empresas-dinese),
ENCOVI INE. Licencias y condiciones pertenecen a cada fuente; no se presume una
licencia común para todo el repositorio. DINESE declara Creative Commons Attribution.

No hacer push, PR, merges ni cambiar la rama predeterminada sin autorización.
